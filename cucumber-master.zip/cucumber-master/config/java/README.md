# Cucumber Config for Java

[![Build Status](https://travis-ci.org/cucumber/config-java.svg?branch=master)](https://travis-ci.org/cucumber/config-java)

[The docs are here](https://docs.cucumber.io/cucumber/configuration/).
