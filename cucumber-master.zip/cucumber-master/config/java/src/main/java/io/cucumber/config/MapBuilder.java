package io.cucumber.config;

import java.util.Map;

interface MapBuilder {
    Map<String, ?> buildMap();
}
