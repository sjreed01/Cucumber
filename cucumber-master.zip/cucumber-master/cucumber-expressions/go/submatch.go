package cucumberexpressions

type Submatch struct {
	value *string
	start int
	end   int
}
