package io.cucumber.cucumberexpressions;

public class DuplicateTypeNameException extends CucumberExpressionException {
    public DuplicateTypeNameException(String message) {
        super(message);
    }
}
