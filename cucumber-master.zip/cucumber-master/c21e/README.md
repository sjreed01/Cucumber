# Cross Platform Executable (c21e)

This is a library for running cross-platform executables.

Cucumber relies executables that are cross-compiled for various CPUs and
operating systems, resulting in 20 or so executables that are bundled inside
packages (gems, jars, npm modules etc).

This library picks the right executable to run for the current CPU/OS.