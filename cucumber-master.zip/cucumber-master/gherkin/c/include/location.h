#ifndef GHERKIN_LOCATION_H_
#define GHERKIN_LOCATION_H_

typedef struct Location {
    int line;
    int column;
} Location;

#endif /* GHERKIN_LOCATION_H_ */
