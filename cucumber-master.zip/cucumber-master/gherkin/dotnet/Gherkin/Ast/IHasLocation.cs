﻿namespace Gherkin.Ast
{
    public interface IHasLocation
    {
        Location Location { get; }
    }
}