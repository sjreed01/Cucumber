﻿namespace Gherkin.Ast
{
    public abstract class Node
    {
    }
}
