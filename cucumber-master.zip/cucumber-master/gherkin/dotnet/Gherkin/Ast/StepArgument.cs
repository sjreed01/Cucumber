﻿namespace Gherkin.Ast
{
    public abstract class StepArgument
    {
        
    }
}