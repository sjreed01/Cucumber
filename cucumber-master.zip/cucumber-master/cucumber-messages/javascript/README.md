# Cucumber Messages for JavaScript (Protocol Buffers)

[![Build Status](https://travis-ci.org/cucumber/cucumber-messages-javascript.svg?branch=master)](https://travis-ci.org/cucumber/cucumber-messages-javascript)
