# Cucumber Messages for Go (Protocol Buffers)

[![Build Status](https://travis-ci.org/cucumber/cucumber-messages-go.svg?branch=master)](https://travis-ci.org/cucumber/cucumber-messages-go)
