# Cucumber Messages for Java (Protocol Buffers)

[![Build Status](https://travis-ci.org/cucumber/cucumber-messages-java.svg?branch=master)](https://travis-ci.org/cucumber/cucumber-messages-java)
