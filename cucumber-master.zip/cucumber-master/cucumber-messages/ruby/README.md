# Cucumber Messages for Ruby (Protocol Buffers)

[![Build Status](https://travis-ci.org/cucumber/cucumber-messages-ruby.svg?branch=master)](https://travis-ci.org/cucumber/cucumber-messages-ruby)
