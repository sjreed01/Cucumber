package io.cucumber.datatable;

enum DiffType {
    NONE, DELETE, INSERT
}
